/* STR_CNMS_LS_011_05 */
char *s = N_("Cancel");
/* STR_CNMS_LS_001_08 */
char *s = N_("Close");
/* STR_CNMS_LS_001_04 */
char *s = N_("Color Mode:");
/* STR_CNMS_LS_011_02 */
char *s = N_("No scanners detected.");
/* STR_CNMS_LS_011_04 */
char *s = N_("OK");
/* STR_CNMS_LS_001_05 */
char *s = N_("Paper Size:");
/* STR_CNMS_LS_008_02 */
char *s = N_("Save");
/* STR_CNMS_LS_008_01 */
char *s = N_("Save Scan Image");
/* STR_CNMS_LS_001_06 */
char *s = N_("Scan (JPEG)");
/* STR_CNMS_LS_001_07 */
char *s = N_("Scan (PDF)");
/* STR_CNMS_LS_001_02 */
char *s = N_("Scan Mode:");
/* STR_CNMS_LS_001_01 */
char *s = N_("Scanner");
/* STR_CNMS_LS_011_01 */
char *s = N_("Select Scanner");
/* STR_CNMS_LS_001_03 */
char *s = N_("Select Source:");
/* STR_CNMS_LS_011_03 */
char *s = N_("Update Scanner List");
/* STR_CNMS_LS_001_09 */
char *s = N_("Version");
