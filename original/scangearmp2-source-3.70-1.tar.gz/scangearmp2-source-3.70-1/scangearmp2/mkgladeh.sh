#!/bin/sh
/usr/bin/intltool-extract --type=gettext/glade scangearmp2.glade > /dev/null

